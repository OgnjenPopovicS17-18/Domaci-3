from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
@app.route('/index')
def index():
	f = open("RAFraspored.csv","r")
	podaci_iz_fajla = f.read()
	redovi_fajla = podaci_iz_fajla.split('\n')
	for red in redovi_fajla:
		splitovan_red = red.split(',')
		predavaci = []
	for red in redovi_fajla:
		if red.split(',')[2] not in predavaci:
			predavaci.append(red.split(',')[2])
		ucionice = []
	for red in redovi_fajla:
		if red.split(',')[6] not in ucionice:
			ucionice.append(red.split(',')[6])
	return render_template('index.html',redovi = redovi_fajla, predavaci= predavaci, ucionice = ucionice)



if __name__ == '__main__':
	app.run(debug=True)